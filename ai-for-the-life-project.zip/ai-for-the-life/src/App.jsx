import Header from './components/Header.jsx'
import Hero from './components/Hero.jsx'
import ContentShowcase from './components/ContentShowcase.jsx'
import EmailSignup from './components/EmailSignup.jsx'
import Footer from './components/Footer.jsx'
import './App.css'

function App() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <Hero />
        <ContentShowcase />
        <EmailSignup />
      </main>
      <Footer />
    </div>
  )
}

export default App

