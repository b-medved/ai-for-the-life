import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Mail, Users, Sparkles, CheckCircle, AlertCircle } from 'lucide-react'
import { emailAPI } from '@/lib/supabase.js'

export default function EmailSignup() {
  const [email, setEmail] = useState('')
  const [reason, setReason] = useState('')
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!email) return

    setIsLoading(true)
    setError('')
    
    try {
      const { data, error: apiError } = await emailAPI.addToWaitlist(email, reason)
      
      if (apiError) {
        setError('Failed to join waitlist. Please try again.')
        console.error('Error adding to waitlist:', apiError)
      } else {
        setIsSubmitted(true)
        // Reset form after success
        setTimeout(() => {
          setIsSubmitted(false)
          setEmail('')
          setReason('')
        }, 5000) // Show success message for 5 seconds
      }
    } catch (err) {
      setError('An unexpected error occurred. Please try again.')
      console.error('Unexpected error:', err)
    } finally {
      setIsLoading(false)
    }
  }

  if (isSubmitted) {
    return (
      <section id="waitlist" className="py-20 bg-gradient-to-br from-primary/5 via-accent/5 to-secondary/10">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <Card className="border-green-200 bg-green-50">
              <CardContent className="pt-6">
                <div className="flex items-center justify-center mb-4">
                  <CheckCircle className="w-16 h-16 text-green-600" />
                </div>
                <h3 className="text-2xl font-bold text-green-800 mb-2">Welcome to the waitlist!</h3>
                <p className="text-green-700">
                  Thank you for joining our community. We'll keep you updated on our progress and be the first to let you know when we launch.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section id="waitlist" className="py-20 bg-gradient-to-br from-primary/5 via-accent/5 to-secondary/10">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 text-accent text-sm font-medium mb-6">
            <Users className="w-4 h-4" />
            Join the community
          </div>
          <h2 className="text-4xl font-bold mb-4">Join the AI for Life waitlist</h2>
          <p className="text-xl text-muted-foreground">
            We're building a calm, curated space to explore AI for everyday life. Be the first to access tools, prompts, and guides.
          </p>
        </div>

        <div className="max-w-lg mx-auto">
          <Card className="shadow-lg">
            <CardHeader className="text-center">
              <CardTitle className="flex items-center justify-center gap-2">
                <Sparkles className="w-5 h-5 text-primary" />
                Early Access
              </CardTitle>
              <CardDescription>
                Get notified when we launch and receive exclusive early access to our curated AI content.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {error && (
                <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-md flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-red-600" />
                  <span className="text-red-700 text-sm">{error}</span>
                </div>
              )}
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label htmlFor="email" className="block text-sm font-medium mb-2">
                    Email address *
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="your@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10"
                      required
                      disabled={isLoading}
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="reason" className="block text-sm font-medium mb-2">
                    Why do you want to join? (optional)
                  </label>
                  <Textarea
                    id="reason"
                    placeholder="Tell us what you're hoping to achieve with AI..."
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    rows={3}
                    disabled={isLoading}
                  />
                </div>

                <Button 
                  type="submit" 
                  className="w-full" 
                  size="lg"
                  disabled={isLoading || !email}
                >
                  {isLoading ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary-foreground mr-2"></div>
                      Joining...
                    </>
                  ) : (
                    <>
                      <Mail className="w-4 h-4 mr-2" />
                      Join the Waitlist
                    </>
                  )}
                </Button>
              </form>

              <div className="mt-6 text-center">
                <p className="text-xs text-muted-foreground">
                  We respect your privacy. No spam, unsubscribe anytime.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Social proof */}
        <div className="max-w-md mx-auto mt-12 text-center">
          <div className="flex items-center justify-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <Users className="w-4 h-4" />
              <span>100+ early members</span>
            </div>
            <div className="w-1 h-1 bg-muted-foreground rounded-full"></div>
            <div className="flex items-center gap-1">
              <Sparkles className="w-4 h-4" />
              <span>Curated content</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

