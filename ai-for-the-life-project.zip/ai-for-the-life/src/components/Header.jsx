import { Button } from '@/components/ui/button.jsx'

export default function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="flex items-center space-x-2">
          <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-sm">AI</span>
          </div>
          <span className="font-semibold text-lg">AI for the Life</span>
        </div>
        <nav className="flex items-center space-x-6">
          <a href="#content" className="text-muted-foreground hover:text-foreground transition-colors">
            Explore
          </a>
          <a href="#waitlist" className="text-muted-foreground hover:text-foreground transition-colors">
            Join
          </a>
        </nav>
      </div>
    </header>
  )
}
